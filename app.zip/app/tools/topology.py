"""app/tools/topology_tools.py

Outil de reconstruction de la topologie réseau (gateways → range‑extenders → sensors)
à partir de la collection **network_nodes** d’une base MongoDB I‑CARE.

⚠️ Les documents sont hétérogènes : certaines DB exposent
`lqi_up` / `lqi_down`, d’autres seulement `rssi`, et parfois aucun
d’indicateur radio.  Ce module :

1. **Construit toujours la topologie** en se basant **uniquement**
   sur les liaisons parents ↔︎ enfant ; aucun filtrage qualité.
2. **Annote** chaque lien avec les métriques disponibles (si elles
   existent) pour que le front / chatbot puisse ensuite :
   • filtrer,  • choisir le « meilleur » parent,  • afficher plus
   d’infos.

Fonctions publiques
-------------------
`get_network_topology(company)` → list[dict]
    Renvoie un objet par gateway :
    {
        "gateway": "00158…",
        "extenders": [
            {
                "address": "E126…",
                "parents": [
                    {"address": "00158…", "metrics": {"lqi_up": 27, "rssi": -78}},
                    …
                ],
                "sensors": [
                    {"address": "A9C3…", "metrics": {"lqi_up": 31}},
                    …
                ],
            },
            …
        ],
        "sensors_direct": [ {"address": "C084…", "metrics": {...}} ],
        "unknown": ["…"],
    }

`topology_to_d3(topo)` → {nodes, links}
    Export prêt pour D3/Sigma ; chaque link possède un champ `metrics`.

Le module **ne fait aucun appel HTTP** : il est destiné à être invoqué
directement par le chatbot (même process).
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any, Dict, Iterable, List, Tuple

from app.db import get_nodes_collection

__all__ = [
    "get_network_topology",
    "topology_to_d3",
]

# ---------------------------------------------------------------------------
# Constantes & cache
# ---------------------------------------------------------------------------
NULL_PARENT = "0000000000000000"
_CACHE_TTL = 60  # secondes
_CACHE: dict[str, Tuple[float, list[dict[str, Any]]]] = {}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_metrics(entry: Any) -> Dict[str, Any]:
    """Retourne un dict {lqi_up, lqi_down, rssi} si présents, sinon vide."""
    if not isinstance(entry, dict):
        return {}
    metrics = {}
    for field in ("lqi_up", "lqi_down", "lqi", "rssi"):
        if field in entry and entry[field] is not None:
            metrics[field] = entry[field]
    return metrics


def _iter_parent_objects(node: Dict[str, Any]) -> List[dict[str, Any]]:
    """Retourne une liste d’objets {address, metrics} pour chaque parent."""
    parents: list[dict[str, Any]] = []

    # Champ "parent" (str) --------------------------------------------------
    p = node.get("parent")
    if isinstance(p, str) and p and p != NULL_PARENT:
        parents.append({"address": p, "metrics": {}})

    # Champ "parents" (array) ----------------------------------------------
    for raw in node.get("parents", []):
        if isinstance(raw, str):
            addr = raw
            metrics: Dict[str, Any] = {}
        elif isinstance(raw, dict):
            addr = raw.get("address")
            metrics = _extract_metrics(raw)
        else:
            continue
        if addr and addr != NULL_PARENT:
            parents.append({"address": addr, "metrics": metrics})

    # Dédupliquer en conservant le premier arrivé ---------------------------
    seen = set()
    uniq: list[dict[str, Any]] = []
    for obj in parents:
        addr = obj["address"]
        if addr not in seen:
            seen.add(addr)
            uniq.append(obj)
    return uniq


def _build_child_index(nodes: Iterable[dict[str, Any]]) -> Dict[str, List[str]]:
    """parent_addr → list[child_addr]"""
    children: Dict[str, List[str]] = defaultdict(list)
    for node in nodes:
        for pobj in _iter_parent_objects(node):
            children[pobj["address"]].append(node["address"])
    return children


# ---------------------------------------------------------------------------
# Algorithme principal
# ---------------------------------------------------------------------------

def _build_topology_for_gateway(
    gw_addr: str,
    nodes_map: Dict[str, dict[str, Any]],
    children_idx: Dict[str, List[str]],
) -> dict[str, Any]:
    """Reconstruit la sous‑topologie d’une gateway."""
    topo: dict[str, Any] = {
        "gateway": gw_addr,
        "extenders": [],        # list[dict]
        "sensors_direct": [],   # list[dict]
        "unknown": [],          # list[str]
    }

    # Pour (re)lier rapidement un extender à son objet dans topo["extenders"]
    ext_map: Dict[str, dict[str, Any]] = {}

    dq: deque[Tuple[str, str | None]] = deque([(gw_addr, None)])  # (current, extender_parent)
    visited: set[str] = {gw_addr}

    while dq:
        current, ext_parent = dq.popleft()
        for child_addr in children_idx.get(current, []):
            if child_addr in visited:
                continue
            visited.add(child_addr)
            child = nodes_map.get(child_addr, {})
            ntype = child.get("node_type")
            parent_objs = _iter_parent_objects(child)
            node_obj = {
                "address": child_addr,
                "metrics": {},  # Nothing directly attached to node itself for now
            }

            if ntype == 3:        # Range‑extender -------------------------
                ext_info = ext_map.get(child_addr)
                if not ext_info:
                    ext_info = {
                        "address": child_addr,
                        "parents": parent_objs,
                        "sensors": [],  # list[dict]
                    }
                    ext_map[child_addr] = ext_info
                    topo["extenders"].append(ext_info)
                dq.append((child_addr, child_addr))

            elif ntype == 2:      # Sensor / transmitter -------------------
                node_obj["metrics"] = _extract_metrics(child)
                if ext_parent:
                    ext_map[ext_parent]["sensors"].append(node_obj)
                else:
                    topo["sensors_direct"].append(node_obj)

            else:                 # Inconnu -------------------------------
                topo["unknown"].append(child_addr)

    return topo


def get_network_topology(company: str, use_cache: bool = True) -> list[dict[str, Any]]:
    """Reconstruit (ou retourne en cache) la topologie d’une entreprise.

    Aucun filtrage qualité.  Tous les liens parents sont conservés, les
    métriques (lqi*, rssi) sont simplement stockées quand elles sont
    présentes.
    """
    if use_cache and (cached := _CACHE.get(company)):
        ts, data = cached
        if time.time() - ts < _CACHE_TTL:
            return data

    # -------------------------- Lecture MongoDB ----------------------------
    coll = get_nodes_collection(company)
    projection = {
        "_id": 0,
        "address": 1,
        "node_type": 1,
        "parent": 1,
        "parents": 1,
        "lqi_up": 1,
        "lqi_down": 1,
        "lqi": 1,
        "rssi": 1,
    }
    nodes: list[dict[str, Any]] = list(coll.find({}, projection))

    nodes_map = {n["address"]: n for n in nodes}
    children_idx = _build_child_index(nodes)

    gateways = [n["address"] for n in nodes if n.get("node_type") == 1]

    topology: list[dict[str, Any]] = [
        _build_topology_for_gateway(gw, nodes_map, children_idx) for gw in gateways
    ]

    if use_cache:
        _CACHE[company] = (time.time(), topology)

    return topology


# ---------------------------------------------------------------------------
# Export D3/Sigma
# ---------------------------------------------------------------------------

def topology_to_d3(topology: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Convertit le résultat en {nodes, links}, avec metrics sur chaque link."""
    nodes_out: list[dict[str, Any]] = []
    links_out: list[dict[str, Any]] = []

    # Helper pour éviter les doublons
    def _add_node(addr: str, ntype: str):
        if not any(n["id"] == addr for n in nodes_out):
            nodes_out.append({"id": addr, "type": ntype})

    # Parcours --------------------------------------------------------------
    for gw in topology:
        gw_addr = gw["gateway"]
        _add_node(gw_addr, "gateway")

        # Sensors directs
        for sensor in gw["sensors_direct"]:
            s_addr = sensor["address"]
            _add_node(s_addr, "sensor")
            links_out.append({
                "source": s_addr,
                "target": gw_addr,
                "metrics": sensor.get("metrics", {}),
            })

        # Extenders et leurs capteurs
        for ext in gw["extenders"]:
            ext_addr = ext["address"]
            _add_node(ext_addr, "extender")

            # Lien(s) parent
            for p in ext["parents"]:
                links_out.append({
                    "source": ext_addr,
                    "target": p["address"],
                    "metrics": p.get("metrics", {}),
                })

            for sensor in ext["sensors"]:
                s_addr = sensor["address"]
                _add_node(s_addr, "sensor")
                links_out.append({
                    "source": s_addr,
                    "target": ext_addr,
                    "metrics": sensor.get("metrics", {}),
                })

    return {"nodes": nodes_out, "links": links_out}
