/* Topology.jsx — patch “nœuds absents” + logs détaillés */
import React, { useEffect, useState, useMemo, useCallback } from "react";
import {
  SigmaContainer,
  useLoadGraph,
  useRegisterEvents,
  useSigma,
  useSetSettings,
} from "@react-sigma/core";
import Graph from "graphology";
import FA2 from "graphology-layout-forceatlas2";
import { Loader2, Network } from "lucide-react";
import { useTopologyStore } from "@/store/useTopologyStore";
import { useNavigate } from "react-router-dom";

/* ------------------------------------------------------------------ */
/* 1. Construction du graphe                                          */
/* ------------------------------------------------------------------ */
function buildGraph(data, { showSensors = true }) {
  const graph = new Graph({ type: "undirected" });
  const colorByType = { gateway: "#1d4ed8", extender: "#16a34a", sensor: "#f97316" };
  const sizeByType  = { gateway: 14, extender: 9, sensor: 5 };

  /* --- nœuds ------------------------------------------------------- */
  data.nodes.forEach((n) => {
    if (!showSensors && n.type === "sensor") return;
    graph.addNode(String(n.id), {
      label: String(n.id),
      kind : n.type,
      type : "circle",
      color: colorByType[n.type] ?? "#64748b",
      size : sizeByType[n.type]  ?? 6,
    });
  });

  /* --- arêtes + détection nœuds manquants -------------------------- */
  const missing = new Set();                       // mémoriser les id absents
  data.links.forEach((e, i) => {

    const s = String(e.source);
    const t = String(e.target);
    const colorByKind = { parent: "#60a5fa", neighbor: "#cbd5e1" };

    /* crée un nœud “placeholder” si besoin */
    [s, t].forEach((id) => {
      if (!graph.hasNode(id)) {
        missing.add(id);
        graph.addNode(id, {
          label: id,
          kind : "unknown",
          type : "circle",
          color: "#94a3b8",          // gris
          size : 4,
        });
      }
    });

    if (!graph.hasEdge(s, t) && !graph.hasEdge(t, s)) {
      graph.addEdge(s, t, { key: `e${i}`, kind: e.kind, color : colorByKind[e.kind] ?? "#cbd5e1" });
    }
  });

  /* --- layout ------------------------------------------------------ */
  const settings = FA2.inferSettings(graph);
  FA2.assign(graph, { settings, iterations: 300 });

  /* --- logs -------------------------------------------------------- */
  console.log(
    `[TOPO] buildGraph → ${graph.order} nodes; ${graph.size} edges;`,
    missing.size ? `(placeholders : ${[...missing].join(", ")})` : ""
  );

  return graph;
}

/* ------------------------------------------------------------------ */
/* 2. Loader Sigma + tooltips (inchangé sauf logs supplémentaire)     */
/* ------------------------------------------------------------------ */
function GraphLoader({ data, filters }) {
  const loadGraph      = useLoadGraph();
  const sigma          = useSigma();
  const registerEvents = useRegisterEvents();
  useSetSettings({ labelRenderedSizeThreshold: 12 });

  const graph = useMemo(() => buildGraph(data, filters), [data, filters]);

  useEffect(() => {
    loadGraph(graph);
    console.log(`[TOPO] graph loaded → ${graph.order} nodes / ${graph.size} edges`);
    sigma.getCamera().animatedReset({ duration: 600 });
  }, [graph, loadGraph, sigma]);

  /* tooltips — identique à ta version précédente */
  useEffect(() => {
    const tip = document.createElement("div");
    tip.className =
      "pointer-events-none fixed z-50 rounded bg-gray-900 text-white text-xs px-2 py-1 opacity-0 transition-opacity";
    document.body.appendChild(tip);

    const show = (e) => {
      const node = e.node;
      if (!node) return;
      const attrs = graph.getNodeAttributes(node);
      tip.textContent = `${attrs.kind?.toUpperCase() ?? "NODE"} – ${node}`;
      tip.style.left  = `${e.event.clientX + 8}px`;
      tip.style.top   = `${e.event.clientY + 8}px`;
      tip.style.opacity = "1";
    };
    const hide = () => (tip.style.opacity = "0");
    registerEvents({ enterNode: show, leaveNode: hide });
    return () => document.body.removeChild(tip);
  }, [graph, registerEvents]);

  return null;
}


/* ------------------------------------------------------------------ */
/* 3. Composant principal                                              */
/* ------------------------------------------------------------------ */
export default function Topology() {
  /* ---------------- état & routing -------------------------------- */
  const qsCompany    = new URLSearchParams(window.location.search).get("company") || "";
  const storeCompany = useTopologyStore.getState().company || "";
  const [company, setCompany]   = useState(qsCompany || storeCompany);
  const [data,    setData]      = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error,   setError]     = useState(null);

  const [quality,      setQuality]     = useState(0);
  const [showSensors,  setShowSensors] = useState(true);

  const navigate    = useNavigate();
  const setTopology = useTopologyStore((s) => s.setTopology);

  /* ---------------- fetch + cache store --------------------------- */
  const fetchData = useCallback(() => {
    if (!company) return;
    const st = useTopologyStore.getState();
    if (st.data && st.company === company) {
      console.log("[TOPO] cache hit → store");
      setData(st.data);
      return;
    }

    console.log("[TOPO] fetching /api/topology/", company);
    setLoading(true);
    setError(null);

    fetch(`/api/topology/${company}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(r)))
      .then((d) => {
        console.log("[TOPO] API raw →", d);
        const g = d.graph || d;
        setData(g);
        setTopology(company, g);
      })
      .catch((err) => {
        console.error("[TOPO] fetch error →", err);
        setError(err.toString());
      })
      .finally(() => setLoading(false));
  }, [company, setTopology]);

  useEffect(fetchData, [fetchData]);

  /* ---------------- counters -------------------------------------- */
  const counts = useMemo(() => {
    if (!data) return { gateways: 0, extenders: 0, sensors: 0 };
    return {
      gateways : data.nodes.filter((n) => n.type === "gateway").length,
      extenders: data.nodes.filter((n) => n.type === "extender").length,
      sensors  : data.nodes.filter((n) => n.type === "sensor").length,
    };
  }, [data]);

  /* ---------------- rendu ----------------------------------------- */
  if (!company) {
    return (
      <p className="p-4">
        No company provided. Use the chat or add&nbsp;
        <code>?company=&lt;slug&gt;</code> to the URL.
      </p>
    );
  }

  return (
    <div className="flex h-screen w-full gap-4 p-4 overflow-hidden">
      {/* --------- panneau latéral --------- */}
      <div className="w-72 shrink-0 overflow-y-auto rounded bg-white shadow p-4 space-y-6">
        <div className="flex items-center gap-2 text-lg font-semibold">
          <Network size={18} /> Topology
        </div>

        {/* company input */}
        <div className="space-y-1 text-sm">
          <label className="font-medium">Company DB</label>
          <input
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            className="w-full rounded border border-gray-300 px-2 py-1 focus:outline-none focus:ring"
          />
          <button
            onClick={() => {
              navigate(`/topology?company=${encodeURIComponent(company)}`);
              fetchData();
            }}
            className="mt-1 w-full rounded bg-blue-600 py-1 font-medium text-white hover:bg-blue-700"
          >
            Reload
          </button>
        </div>

        {/* summary */}
        <div className="text-sm">
          <div className="font-semibold">Summary</div>
          <div>Gateways : {counts.gateways}</div>
          <div>Extenders : {counts.extenders}</div>
          <div>Sensors  : {counts.sensors}</div>
        </div>
        
        
        {/* quality slider */}
        <div className="space-y-1 text-sm">
          <div className="flex justify-between font-semibold">
            <span>Min. quality</span>
            <span>{quality}</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={quality}
            onChange={(e) => setQuality(Number(e.target.value))}
            className="w-full"
          />
        </div>

        {/* sensors toggle */}
        <div className="flex items-center gap-2 text-sm font-semibold">
          <input
            type="checkbox"
            checked={showSensors}
            onChange={(e) => setShowSensors(e.target.checked)}
          />
          Sensors
        </div>
      </div>

      {/* --------- zone graphe --------- */}
      <div className="relative flex-1 h-full">
        {loading && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/70">
            <Loader2 className="animate-spin text-blue-600" size={32} />
          </div>
        )}
        {error && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/70 text-red-600">
            {error}
          </div>
        )}
        {data && !loading && !error && (
          <SigmaContainer
            className="h-full w-full rounded bg-white shadow"
            settings={{ allowInvalidContainer: true }}
          >
            <GraphLoader data={data} filters={{ quality, showSensors }} />
          </SigmaContainer>
        )}
      </div>
    </div>
  );
}
